/*******************************************************************************************************
saludos.java
Autor: Diego Perdomo, Ana Ramirez, Maria Fernanada Argueta, Jose Gonzalez, Carol Arevalo
Última modificación: 11/09/20

Ejercicios correspondientes vida diaria
********************************************************************************************************/

//tomar en cuenta que la clase al momento de tener el ejercicio bueno debe retornar un 1
public class saludos{
  String retornos;
  public String saluda(){
    retornos = "Actualmente se encuentra en mantenimiento la sección de ejercicios de saludos";
    return retornos ;
  }
  /*public int calificas(int op){
    if (op == 1){
      return 1;
    }else if(op ==2){
      return 0;
    }
  }*/
}
