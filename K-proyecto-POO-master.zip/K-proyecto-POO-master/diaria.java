/*******************************************************************************************************
diaria.java
Autor: Diego Perdomo, Ana Ramirez, Maria Fernanada Argueta, Jose Gonzalez, Carol Arevalo
Última modificación: 11/09/20

Ejercicios correspondientes a vida diaria
********************************************************************************************************/

//tomar en cuenta que la clase al momento de tener el ejercicio bueno debe retornar un 1
public class diaria{
  String retornod;
  public String diari(){
    retornod = "Actualmente se encuentra en mantenimiento la sección de ejercicios de vida cotidiana";
    return retornod ;
  }
  /*public int calificad(int op){
    if (op == 1){
      return 1;
    }else if(op ==2){
      return 0;
    }
  }*/
}
