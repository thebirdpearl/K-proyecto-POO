/*****************************************************************************************
diccionario.java
Autor: Diego Perdomo, Ana Ramirez, Maria Fernanada Argueta, Jose Gonzalez, Carol Arevalo

Contiene las palabras en español y kaqchikel que tiene registradas el sistema.
*****************************************************************************************/

import java.util.ArrayList;

public class diccionario 
{
    public ArrayList <String> esp = new ArrayList<String>();
    public ArrayList <String> kaq = new ArrayList<String>();

    public diccionario()
    {
        //Voc de saludos
        esp.add("Buenos dias");
        esp.add("Gracias");
        esp.add("Buenas noches");
        esp.add("¿Como estas?");
        esp.add("Bien gracias");

        //Voc de familia
        esp.add("Familia");
        esp.add("Madre");
        esp.add("Padre");
        esp.add("Hijos");
        esp.add("Nieto");

        //Voc de diario
        esp.add("¿Cual es tu nombre?");
        esp.add("Dormitorio");
        esp.add("Sala");
        esp.add("Baño");
        esp.add("Cocina");

        esp.add("Cabeza");
        esp.add("Oreja");
        esp.add("Nariz");
        esp.add("Ojos");
        esp.add("Boca");

        kaq.add("Saqer");
        kaq.add("Matyox");
        kaq.add("Xo’qa");
        kaq.add("La ütz awäch?");
        kaq.add("Ütz matyox");

        kaq.add("Ach´alal");
        kaq.add("Te´ej");
        kaq.add("Tata´aj");
        kaq.add("Alk´walaxela");
        kaq.add("mam");

        kaq.add("Achike ab’i’ rat?");
        kaq.add("warab’äl");
        kaq.add("nimajay");
        kaq.add("ruxikin jay");
        kaq.add("ruchi’ q’aq’");

        kaq.add("jolomaj");
        kaq.add("xikinaj");
        kaq.add("tzamaj");
        kaq.add("runaq’ wachaj");
        kaq.add("chi’aj");
    }

}
