//tomar en cuenta que la clase al momento de tener el ejercicio bueno debe retornar un 1
public class familia{
  String retornof;
  public String famili(){
    retornof = "Actualmente se encuentra en mantenimiento la sección de ejercicios de familia";
    return retornof ;
  }
  /*public int calificaf(int op){
    if (op == 1){
      return 1;
    }else if(op ==2){
      return 0;
    }
  }*/
}
